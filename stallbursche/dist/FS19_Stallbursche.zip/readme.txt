1.20.1.19
- first release

1.20.4.10
- checking pallets added (eggs, wool)

1.20.8.16
- checking reproduction available now works as expected, even the husbandry is full
