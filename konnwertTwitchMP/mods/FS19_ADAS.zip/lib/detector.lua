--[[
	DETECTOR
]]

-- lib
local detector = {};

-- export
FS19_ADAS.lib.detector = detector;

-- import shortcuts
local logging;
local utils;

local COLLISION_MASK = 0;

-- required
function detector:load(mod)
	-- refs
	logging = FS19_ADAS.lib.logging;
	utils   = FS19_ADAS.lib.utils;
	
	--------------------------------------------------------
	local ADCollSensor = {};
	ADCollSensor.collisionMask = 239
	ADCollSensor.mask_Non_Pushable_1 = 1
	ADCollSensor.mask_Non_Pushable_2 = 2
	ADCollSensor.mask_static_world_1 = 3
	ADCollSensor.mask_static_world_2 = 4
	ADCollSensor.mask_tractors = 6
	ADCollSensor.mask_combines = 7
	ADCollSensor.mask_trailers = 8
	ADCollSensor.mask_dynamic_objects = 12
	ADCollSensor.mask_dynamic_objects_machines = 13
	ADCollSensor.mask_trigger_player = 20
	ADCollSensor.mask_trigger_tractor = 21
	ADCollSensor.mask_trigger_combines = 22
	ADCollSensor.mask_trigger_fillables = 23
	ADCollSensor.mask_trigger_dynamic_objects = 24
	ADCollSensor.mask_trigger_trafficVehicles = 25
	ADCollSensor.mask_trigger_cutters = 26
	ADCollSensor.mask_kinematic_objects_wo_coll = 30

	local mask = 0

	mask = mask + math.pow(2, ADCollSensor.mask_Non_Pushable_1 - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_Non_Pushable_2 - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_static_world_1 - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_static_world_2 - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_tractors - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_combines - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_trailers - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_dynamic_objects - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_dynamic_objects_machines - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_trigger_trafficVehicles - 1)
	mask = mask + math.pow(2, ADCollSensor.mask_trigger_dynamic_objects - 1)
	COLLISION_MASK = mask;

	logging.trace("COLLISION_MASK: " .. COLLISION_MASK);
end

function detector.getPlayerPositionNode()
	-- ok thats yourself
	local player = g_currentMission.player;

	-- when the player is inside a vehicle, we have to use the position of that vehicle.
	-- in that case the player position is not updated. if the player is not in a vehicle, 
	-- means he is walking, the player position is correct.
	-- note: controlledVehicle can be nil
	return (g_currentMission.controlledVehicle or {}).rootNode or player.rootNode;
end

local test = true;

-- we are looking down to the map and find the nearest whatever
function detector.detectObjectsInRange(nodeToCheck, maxDistance, includeSelf)
	-- callback object
	local resolver = {
		checked  = {},
		objects  = {},
		callback = function(self, transformId)
			-- getRigidBodyType(transformId)
			local object = g_currentMission:getNodeObject(transformId);
			local key    = (object and object.id) or transformId;

			if not self.checked[key] then
				if (object ~= nil and object.isa ~= nil and ((object.rootNode ~= nodeToCheck) or includeSelf == true)) then
					table.insert(self.objects, object);
				end

				-- remember was checked
				self.checked[key] = true;
			end

			-- continue
			return true;
		end
	};

	local callback        = "callback";
	local targetObject    = resolver;
	local collisionMask   = nil;
	--local collisionMask   = 16783599;
	--local collisionMask   = COLLISION_MASK; -- 25172207
	--local collistionMask  = 5468288;
	local includeDynamics = true;
	local includeStatics  = true;
	local exactTest       = false;

	local x, y, z = getWorldTranslation(nodeToCheck);
	local centerX = x;
	local centerY = y;
	local centerZ = z;
	local extentX = 2 * maxDistance;
	local extentY = 10;
	local extentZ = 2 * maxDistance;

	overlapBox(centerX, centerY, centerZ, x, y, z, extentX, extentY, extentZ, callback, targetObject, collisionMask, includeDynamics, includeStatics, exactTest);

	return resolver.objects;
end

-- https://gdn.giants-software.com/documentation_scripting_fs19.php?version=script&category=26&class=247#groundRaycastCallback2642
function detector.detectTerrainHeightWithProps(nodeToCheck, x, z)
	local terrainY = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, x, 0, z);

	local resolver = {
		data = nil,		
		callback = function(self, hitObjectId, x, y, z, distance)
			if (hitObjectId ~= nil) then
				local objectType = getRigidBodyType(hitObjectId);

				if (objectType ~= "Dynamic" and objectType ~= "Kinematic") then
					self.data = {x = x, y = math.max(terrainY, y), z = z, distance = distance};
					return false;
				end
			end

			-- continue
			return true;
		end
	};

    local offset        = 1.0;
    local distance      = 20.0;
    local collisionMask = 63;

    raycastClosest(x, terrainY + offset, z, 0, -1, 0, "callback", 5.0, resolver, collisionMask);

	return resolver.data;
end

