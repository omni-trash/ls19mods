--[[
	DEMO VEHICLE_COLLISION
]]

-- lib
local demo = {
};

-- export
FS19_ADAS.lib.demo = demo;

-- import shortcuts
local detector;
local graphics;
local logging;
local utils;
local vehicle_measurement;

-- update interval
local nextUpdate = 0;

-- for internal use
local debugVehicleBox  = true;

-- required
function demo:load(mod)
	-- refs
	detector            = FS19_ADAS.lib.detector;
	graphics            = FS19_ADAS.lib.graphics;
	logging             = FS19_ADAS.lib.logging;
	utils               = FS19_ADAS.lib.utils;
	vehicle_measurement = FS19_ADAS.lib.vehicle_measurement;
end

function demo:update(dt)
end

--[[
function demo:groundRaycastCallback(hitObjectId, x, y, z, distance)
	if hitObjectId ~= nil then
		self.groundY = math.max(self.groundY, y);
		return false;
	end

	-- continue;
	return true;
end

function demo:distanceRaycastCallback(hitObjectId, x, y, z, distance)
	if hitObjectId ~= nil then
		self.distanceRayastResult = {x = x, y = y, z = z, distance = distance};
		return false;
	end

	-- continue;
	return true;
end

function demo:hitObjectRaycastCallback(hitObjectId, x, y, z, distance)
	if hitObjectId == self.hitObjectId then
		self.hitObjectResult = {hitObjectId = hitObjectId, x = x, y = y, z = z, distance = distance};
		return false;
	end

	-- continue;
	return true;
end

function demo:hitAnyObjectRaycastCallback(hitObjectId, x, y, z, distance)
	if hitObjectId ~= nil then
		self.hitObjectResult = {hitObjectId = hitObjectId, x = x, y = y, z = z, distance = distance};
		return false;
	end

	-- continue;
	return true;
end

function demo:hitAnyVehicleRaycastCallback(hitObjectId, x, y, z, distance)
	local object = hitObjectId and g_currentMission:getNodeObject(hitObjectId);

	if (object ~= nil and object.isa ~= nil and object:isa(Vehicle)) then
		self.hitObjectResult = {hitObject = object, hitObjectId = hitObjectId, x = x, y = y, z = z, distance = distance};
		return false;
	end

	-- continue;
	return true;
end

function demo:hitComponentOverlapCallback(transformId)
	if (transformId and self.hitComponents[transformId]) then
		self.hitComponentResult = {transformid = transformid};
		return false;
	end

	-- continue;
	return true;
end

self.raycastCallback = function(hitObjectId, x, y, z, distance)
	if (hitObjectId == self.hitObjectId) or (self.hitObject and getParent(hitObjectId) == self.hitObject) then
		self.hitObjectResult = {hitObjectId = hitObjectId, x = x, y = y, z = z, distance = distance};
		return false;
	end

	-- continue;
	return true;
end
]]

--[[
	-- getRigidBodyType(transformId)
	local object = g_currentMission:getNodeObject(transformId);
	local key    = (object and object.id) or transformId;

	if not self.checked[key] then
		if (object ~= nil and object.isa ~= nil and ((object.rootNode ~= nodeToCheck) or includeSelf == true)) then
			table.insert(self.objects, object);
		end

		-- remember was checked
		self.checked[key] = true;
	end

	-- continue
	return true;
	
function demo:bob(transformId)
	-- check is shape
	if (transformId and getHasClassId(transformId, ClassIds.SHAPE)) then
		local hitObjectId = getParent(transformId);

		if (hitObjectId and getSplitType(transformId)) then
			--getschapesphere oder so ähnlich
			local x, y, z = localToLocal(player, transformId, x, y, z);
			self.groundY = math.max(self.groundY, y);
		end
	end

	-- continue
	return true;
end
]]

local previousVehicleNode;

function demo:draw()
	----------
	-- https://gdn.giants-software.com/documentation_scripting_fs19.php?version=script&category=28&class=281
	-- localDirectionToWorld
	-- Player:updateRotation(dt)
	--
	--  local x, _, z = localDirectionToLocal(self.cameraNode, getParent(self.cameraNode), 0, 0, 1)
	--	local alpha = math.atan2(x, z)
	--	self.cameraRotY = alpha
	----------
	
	local vehicle = g_currentMission.controlledVehicle
	
	if (not vehicle) then
		return;
	end
	
--[[
coordinate system, (0,0,0) is top left of map
              y+  (N)
              |   z-
              |  /
              | /
              |/
(W) x- -------0------- x+ (E)
             /|
            / |
           /  |
          z+  |
        (S)   y-
]]

	local nodeToCheck = vehicle.rootNode;
	--local nodeToCheck = (g_currentMission.controlledVehicle or {}).rootNode or getCamera();

	if (nodeToCheck ~= previousVehicleNode) then
		previousVehicleNode = nodeToCheck;
		--logging.trace("------------------------------------------------------");
		--logging.trace(vehicle.sizeLength .. " " .. vehicle.sizeWidth .. " " .. vehicle.lengthOffset .. " " .. vehicle.widthOffset);
		--logging.printTable("vehicle", vehicle, 2);
	end

	--demo:drawArea(vehicle);

	--[[

	-- ok
	local pen  = {thickness = 2 / g_screenHeight, color = {r = 1, g = 0, b = 0, a = 0.6}};
	local pen2 = {thickness = 2 / g_screenHeight, color = {r = 0, g = 0, b = 1, a = 0.6}};
	local pen3 = {thickness = 2 / g_screenHeight, color = {r = 0, g = 1, b = 0, a = 0.6}};
	local pen4 = {thickness = 2 / g_screenHeight, color = {r = 0.5, g = 0.5, b = 0.5, a = 0.61}};

	-- draw grid
	local points2D = {};
	
	-- positions to check, scan lines
	local scanlines = {};
	
	for dy = 0, 5, 1 do
		local line = {};

		for dx = -5, 5, 1 do
			local x, y, z = localToWorld(nodeToCheck, dx * vehicleWidth / 10, dy, vehicleLength / 2 + 40);
			table.insert(line, {x = x, y = y, z = z});		

			local screenX, screenY = project(x, y, z);
			table.insert(points2D, {x = screenX, y = screenY});
		end

		table.insert(scanlines, line);
	end

	--graphics.drawPoly(points2D, pen);

	local nodeX, nodeY, nodeZ = getWorldTranslation(nodeToCheck);
	-- muss ausserhalb liegen, länge vom vehicle?
	local startX, startY, startZ = localToWorld(nodeToCheck, -5 * vehicleWidth / 10, 1, vehicleLength / 2);

	for _, line in pairs(scanlines) do
		points2D = {};
		
		for _, position in pairs(line) do
			--g_currentMission.terrainDetailId
			--local terrainY = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, position.x, 0, position.z);
			--self.groundY = -1;

			local dirX, dirY, dirZ = position.x - startX, position.y - startY, position.z - startZ;
			local dirLength = MathUtil.vector3Length(dirX, dirY, dirZ);

			dirX = dirX / dirLength;
			dirY = dirY / dirLength;
			dirZ = dirZ / dirLength;

			self.distanceRayastResult = nil;
			raycastClosest(startX, startY, startZ, dirX, dirY, dirZ, "distanceRaycastCallback", 40, self, 63);

			if (self.distanceRayastResult) then
				local screenX, screenY = project(self.distanceRayastResult.x, self.distanceRayastResult.y, self.distanceRayastResult.z);
				table.insert(points2D, {x = screenX, y = screenY});
			else
				local screenX, screenY = project(position.x, position.y, position.z);
				table.insert(points2D, {x = screenX, y = screenY});			
			end
		end
		
		graphics.drawPoly(points2D, pen2);
	end

	local startX, startY, startZ = localToWorld(nodeToCheck, 5 * vehicleWidth / 10, 1, vehicleLength / 2);
	
	for _, line in pairs(scanlines) do
		points2D = {};

		for _, position in pairs(line) do
			--g_currentMission.terrainDetailId
			--local terrainY = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, position.x, 0, position.z);
			--self.groundY = -1;

			local dirX, dirY, dirZ = position.x - startX, position.y - startY, position.z - startZ;
			local dirLength = MathUtil.vector3Length(dirX, dirY, dirZ);

			dirX = dirX / dirLength;
			dirY = dirY / dirLength;
			dirZ = dirZ / dirLength;

			self.distanceRayastResult = nil;
			raycastClosest(startX, startY, startZ, dirX, dirY, dirZ, "distanceRaycastCallback", 40, self, 63);

			if (self.distanceRayastResult) then
				local screenX, screenY = project(self.distanceRayastResult.x, self.distanceRayastResult.y, self.distanceRayastResult.z);
				table.insert(points2D, {x = screenX, y = screenY});
			else
				local screenX, screenY = project(position.x, position.y, position.z);
				table.insert(points2D, {x = screenX, y = screenY});			
			end
		end

		graphics.drawPoly(points2D, pen3);
	end
	]]
end

-- helper prop(instance, "a.b.c") => return instance.a.b.c
local function prop(v, path)
	for w in string.gmatch(path, "[%w_]+") do
        v = v and v[w];
    end

	return v;
end

function demo:drawArea(vehicle)
	-- vehicle box
	local boxes      = {};
	local vehicleBox = vehicle_measurement:getVehicleBox(vehicle, boxes, {ignoreObjectsOnTrailer = false, alignToFirstBox = false});

	-- debug ----------------------------------------------------------------------------------
	if (debugVehicleBox) then
		for _, box in pairs(boxes) do
			-- pulse	
			local o = (box.rootNode % 5) * 1000;
			local r = utils.pulse(o +  5000);
			local g = utils.pulse(o + 10000);
			local b = utils.pulse(o + 15000);

			local magentaPen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 0, b = 1, a = 0.6 }};
			local boxPen     = {thickness = 1 / g_screenHeight, color = {r = r, g = g, b = b, a = 0.6 }};

			-- draw line from rootNode to center of the box
			local p1 = graphics.toPoint(project(localToWorld(box.rootNode, 0, 0, 0)));
			local p2 = graphics.toPoint(project(localToWorld(box.rootNode, box.offsetX, box.offsetY, box.offsetZ)));
			graphics.drawPoly({p1, p2}, magentaPen);

			-- draw direction (triangle)
			local p1 = graphics.toPoint(project(localToWorld(box.rootNode, -1, 0, 0)));
			local p2 = graphics.toPoint(project(localToWorld(box.rootNode,  1, 0, 0)));
			local p3 = graphics.toPoint(project(localToWorld(box.rootNode,  0, 0, 2)));
			graphics.drawPoly({p1, p2, p3, p1}, boxPen);

			-- draw the box around the vehicle
			vehicle_measurement.drawVehicleBox(box, boxPen);
		end
	end

	local frontBox = vehicleBox;
	
	local redPen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 0, b = 0, a = 0.6 }};

	for _, box in pairs(boxes) do
		-- check object is on front
		local dx, dy, dz = localToLocal(box.rootNode, frontBox.rootNode, 0,0,0);

		--- draw line
		local p1 = graphics.toPoint(project(localToWorld(frontBox.rootNode, 0, 0, 0)));
		local p2 = graphics.toPoint(project(localToWorld(frontBox.rootNode, dx, dy, dz)));
		graphics.drawPoly({p1, p2,p1}, redPen);

		if (dz > 0 and math.abs(dx) < 2) then
			frontBox = box;
		end
	end

	-------------------------------------------------------------------------------------------
	-- scan box
	local scanWidth  = frontBox.width;
	local scanLenght = 20;
	local scanHeight = frontBox.height;

	-- vehicle moving
	local rotationX, rotationY, rotationZ = getWorldRotation(frontBox.rotationNode);

	-- diff from rotation node to vehicle node
	local dx, dy, dz = localToLocal(frontBox.rootNode, frontBox.rotationNode, 0, 0, 0);

	-- center front of front box
	local x, y, z = localToWorld(frontBox.rotationNode, dx + frontBox.offsetX + frontBox.width / 2, dy + frontBox.offsetY, dz + frontBox.offsetZ + frontBox.length / 2);

	local overPen    = {thickness = 2 / g_screenHeight, color = {r = 0, g = 0, b = 1, a = 0.6}};
	local underPen   = {thickness = 2 / g_screenHeight, color = {r = 0, g = 1, b = 0, a = 0.6}};
	local defaultPen = {thickness = 2 / g_screenHeight, color = {r = 0.5, g = 0.5, b = 0.5, a = 0.61}};

	-- draw grid
	local points2D = {};
	
	-- positions to check, scan grid
	local points3D = {};

	-- 10x10 on the ground of our scan box
	for sz = 0, scanLenght, (scanLenght / 10) do
		for sx = 0, scanWidth, (scanWidth / 10) do
			-- y = bottom of box, (offsetY - height / 2)
			table.insert(points3D, {localToWorld(frontBox.rotationNode, dx + frontBox.offsetX + scanWidth / 2 - sx, dy, dz + frontBox.offsetZ + frontBox.length / 2 + sz)});
		end
	end

	for _, point3D in pairs(points3D) do
		local terrainY = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, point3D[1], point3D[2], point3D[3]);

		self.groundY = -1;
		raycastClosest(point3D[1], point3D[2] + scanHeight, point3D[3], 0, -1, 0, "groundRaycastCallback", scanHeight + 5, self, 63);

		local h = math.max(terrainY, self.groundY);

		local screenX,  screenY  = project(point3D[1], h,     point3D[3]);
		local screenX2, screenY2 = project(point3D[1], h - 1, point3D[3]);

		if (point3D[2] - h < -0.5) then
			-- collision
			graphics.drawLine(screenX, screenY, screenX2, screenY2, overPen);
		elseif (point3D[2] - h > 0.5) then
			-- falling
			graphics.drawLine(screenX, screenY, screenX2, screenY2, underPen);
		else
			-- accepted range
			graphics.drawLine(screenX, screenY, screenX2, screenY2, defaultPen);
		end

		table.insert(points2D, {x = screenX, y = screenY});
	end

	graphics.drawPoly(points2D, defaultPen);
end


----------
-- https://gdn.giants-software.com/documentation_scripting_fs19.php?version=script&category=28&class=281
-- localDirectionToWorld
-- Player:updateRotation(dt)
--
--  local x, _, z = localDirectionToLocal(self.cameraNode, getParent(self.cameraNode), 0, 0, 1)
--	local alpha = math.atan2(x, z)
--	self.cameraRotY = alpha
----------
	
--[[
function WildlifeSpawner:getIsOnField(x, y, z)
    local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailId, x, y, z)
    return densityBits ~= 0
end

----------------------------

function MyScript:getDistance()
self.distance = 0
self.hitTerrain = false

local x, y, z = getWorldTranslation(self.implementNode)
raycastClosest(x, y, z, 0, -1, 0, "raycastCallback", 10, self, 59)

return self.distance, self.hitTerrain
end

function MyScript:raycastCallback(hitObjectId, x, y, z, distance)
if hitObjectId == g_currentMission.terrainRootNode then
self.hitTerrain = true
self.distance = distance
end

return false
end

-----------------------------

 AITurnStrategy:getIsBoxColliding(box)
 
-----------------------------
https://gdn.giants-software.com/documentation_scripting_fs19.php?version=script&category=1&class=7#getIsBoxColliding54

for i=0,steps do
        local alpha = math.min(1/(steps+1)*(i+math.random()), 1)
        local x, z = MathUtil.lerp(x1, x2, alpha), MathUtil.lerp(z1, z2, alpha)
        local _, densityHeight = DensityMapHeightUtil.getHeightAtWorldPos(x, 0, z)
        if densityHeight >= AITurnStrategy.DENSITY_HEIGHT_THRESHOLD then
            box.color = AITurnStrategy.COLLISION_BOX_COLOR_HIT
            return true
        end
    end


]]


--[[
	for step = 1, 10, 1 do
		local offsetZ = vehicleBoxLengthHalf + step - 0.5;

		-- check left (local coordinate)
		-- align x (previously calculated)
		local x, y, z = localToWorld(vehicle.rootNode, vehicleBox.offsetX, 0, offsetZ);

		local centerX = x;
		local centerY = y;
		local centerZ = z;
		local extentX = vehicleBox.width / 2; -- current width
		local extentY = 7;
		local extentZ = 0.5;

		local collisionMask   = nil;
		local includeDynamics = true;
		local includeStatics  = true;
		local exactTest       = true;

		local resolver = overlapBoxComponentsResolver:init(vehicle);

		overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

		if not resolver.result then
			break;
		end

		vehicleBox.length  = vehicleBox.length  + 1;
		vehicleBox.offsetZ = vehicleBox.offsetZ + 0.5;

		-- measurement both sides required
		lengthChanged = true;

		-- debug ----------------------------------------------------------------------------------
		if (debugEnabled) then
			local p1 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX - extentX, 0, offsetZ + extentZ)));
			local p2 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX - extentX, 0, offsetZ - extentZ)));
			local p3 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX + extentX, 0, offsetZ - extentZ)));
			local p4 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX + extentX, 0, offsetZ + extentZ)));

			local pen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 1, b = 0, a = 1 }};

			graphics.drawPoly({p1, p2, p3, p4, p1}, pen);
		end
		-------------------------------------------------------------------------------------------
	end
]]
	------------------------------------------------------------
	-- measurement back
	------------------------------------------------------------
--[[
	for step = 1, 10, 1 do
		local offsetZ = vehicleBox.length / 2 - 0.5;
		local x, y, z = localToWorld(vehicle.rootNode, vehicleBox.offsetX, vehicleBox.offsetY, vehicleBox.offsetZ - offsetZ);

		local centerX = x;
		local centerY = y;
		local centerZ = z;
		local extentX = vehicleBox.width / 2;
		local extentY = 7;
		local extentZ = 0.5;

		local collisionMask   = nil;
		local includeDynamics = true;
		local includeStatics  = true;
		local exactTest       = true;

		local resolver = overlapBoxComponentsResolver:init(vehicle);

		overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

		if not resolver.result then
			break;
		end

		vehicleBox.length  = vehicleBox.length  + 1;
		vehicleBox.offsetZ = vehicleBox.offsetZ - 0.5;

		-- measurement both sides required
		lengthChanged = true;

		-- debug ----------------------------------------------------------------------------------
		if (debugEnabled) then
			local p1 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX - extentX, 0, -offsetZ + extentZ)));
			local p2 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX - extentX, 0, -offsetZ - extentZ)));
			local p3 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX + extentX, 0, -offsetZ - extentZ)));
			local p4 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX + extentX, 0, -offsetZ + extentZ)));

			local pen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 1, b = 0, a = 1 }};

			graphics.drawPoly({p1, p2, p3, p4, p1}, pen);
		end
		-------------------------------------------------------------------------------------------
	end

	if (lengthChanged) then
		-- do it again ... or not
	end

	local heightChanged = false;
]]
	------------------------------------------------------------
	-- measurement height
	------------------------------------------------------------
--[[
	for step = 1, 10, 1 do
		local offsetY = vehicleBox.height + 0.5;
		local x, y, z = localToWorld(vehicle.rootNode, vehicleBox.offsetX, offsetY, vehicleBox.offsetZ);

		local centerX = x;
		local centerY = y;
		local centerZ = z;
		local extentX = vehicleBox.width  / 2;
		local extentY = 0.5;
		local extentZ = vehicleBox.length / 2;

		local collisionMask   = nil;
		local includeDynamics = true;
		local includeStatics  = true;
		local exactTest       = true;

		local resolver = overlapBoxComponentsResolver:init(vehicle);

		overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

		if not resolver.result then
			break;
		end

		vehicleBox.height  = vehicleBox.height  + 1;
		--vehicleBox.offsetY = vehicleBox.offsetY + 1;

		-- measurement both sides required
		heightChanged = true;

		-- debug ----------------------------------------------------------------------------------
		if (debugEnabled) then
			local p1 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX - extentX, offsetY - extentY, vehicleBox.offsetZ - extentZ)));
			local p2 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX - extentX, offsetY + extentY, vehicleBox.offsetZ - extentZ)));
			local p3 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX + extentX, offsetY + extentY, vehicleBox.offsetZ - extentZ)));
			local p4 = graphics.toPoint(project(localToWorld(vehicle.rootNode, vehicleBox.offsetX + extentX, offsetY - extentY, vehicleBox.offsetZ - extentZ)));

			local pen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 1, b = 0, a = 1 }};

			graphics.drawPoly({p1, p2, p3, p4, p1}, pen);
		end
		-------------------------------------------------------------------------------------------
	end
]]
--[[
	------------------------------------------------------------
	-- determine height
	------------------------------------------------------------

	-- raycast 7m over the node to check
	local raycastDistance = 7;
	local targetResult    = nil;

	--local terrainY = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, nodeX, nodeY, nodeZ);
	--	terrainDetailId
	--self.groundY = -1;
	--raycastClosest(nodeX, nodeY + raycastDistance, nodeZ, 0, -1, 0, "groundRaycastCallback", raycastDistance, self, 63);

	-- 3x3 (no idea how do it better, but maybe height is not so important)
	-- TODO: would it better to raycast fron x-axis instaed onf y-axis?
	local dx = vehicleBox.width  / 4;
	local dz = vehicleBox.length / 4;

	local pointsToCheck = {
		{x = -dx, z = -dz},
		{x = -dx, z =   0},
		{x = -dx, z =  dz},

		{x =   0, z = -dz},
		{x =   0, z =   0},
		{x =   0, z =  dz},

		{x =  dx, z = -dz},
		{x =  dx, z =   0},
		{x =  dx, z =  dz},
	};

	for _, pointToCheck in pairs(pointsToCheck) do
		local toX,   toY,   toZ   = localToWorld(vehicle.rootNode, pointToCheck.x, 0, pointToCheck.z);
		local fromX, fromY, fromZ = localToWorld(vehicle.rootNode, pointToCheck.x, raycastDistance, pointToCheck.z);

		local dirX, dirY, dirZ = localDirectionToWorld(vehicle.rootNode, 0, -1, 0);

		self.hitObjectId     = vehicle.rootNode;
		self.hitObjectResult = nil;

		-- no shapes, no placeables, but maybe bales on trailer
		raycastAll(fromX, fromY, fromZ, dirX, dirY, dirZ, "hitAnyVehicleRaycastCallback", raycastDistance, self, 63);

		if (self.hitObjectResult) then
			-- remember min distance (furthest point from vehicle root node with match)
			if (not targetResult or self.hitObjectResult.distance < targetResult.distance) then
				targetResult = {
					from = {
						x = fromX, 
						y = fromY, 
						z = fromZ
					},
					to = {
						x = toX,
						y = toY,
						z = toZ
					},
					found = {
						x = self.hitObjectResult.x,
						y = self.hitObjectResult.y,
						z = self.hitObjectResult.z
					},
					-- range between [from] and [found]
					distance = self.hitObjectResult.distance
				};
			end

			-- debug ----------------------------------------------------------------------------------
			if (debugEnabled) then
				local aX, aY = project(fromX, fromY, fromZ);
				local bX, bY = project(self.hitObjectResult.x, self.hitObjectResult.y, self.hitObjectResult.z);
				graphics.drawLine(aX, aY, bX, bY, {thickness = 1 / g_screenHeight, color = {r = 0, g = 1, b = 1, a = 1}});
			end
			-------------------------------------------------------------------------------------------
		end	
	end

	-- update vehicle height
	if (targetResult) then
		-- range beetween [found] and [to] (the vehicle root node)
		vehicleBox.height = math.sqrt(math.pow(targetResult.found.x - targetResult.to.x, 2) + math.pow(targetResult.found.y - targetResult.to.y, 2) + math.pow(targetResult.found.z - targetResult.to.z, 2));

		-- think the height should be 20cm at minimum
		vehicleBox.height = math.max(0.2, vehicleBox.height);
	end
]]