--[[
	VEHICLE_MEASUREMENT
]]

-- lib
local vehicle_measurement = {
};

-- export
FS19_ADAS.lib.vehicle_measurement = vehicle_measurement;

-- import shortcuts
local graphics;
local logging;
local utils;

-- for internal use
local debugMeasurement = false;

-- required
function vehicle_measurement:load(mod)
	-- refs
	graphics  = FS19_ADAS.lib.graphics;
	logging   = FS19_ADAS.lib.logging;
	utils     = FS19_ADAS.lib.utils;
end

-- overlapBox callback resolver to check transformId is a known component of the vehicle
local overlapBoxComponentsResolver = {
	componentsToCheck = {},
	result = nil,
	cache = {},
	init = function(self, vehicle)
		local componentsToCheck = self.cache[vehicle.rootNode];

		if not componentsToCheck then
			componentsToCheck = {};

			-- Note: vehicle.components[1].node is vehicle.rootNode
			for _, component in pairs(vehicle.components) do
				componentsToCheck[component.node] = component;
			end

			self.cache[vehicle.rootNode] = componentsToCheck;
		end

		self.componentsToCheck = componentsToCheck;
		self.result = nil;
		return self;
	end,
	callback = function(self, transformId)
		if (transformId and self.componentsToCheck[transformId]) then
			self.result = {transformId = transformId};
			return false;
		end

		-- continue;
		return true;
	end
};

-- overlapBox callback resolver to check transformId is a vehicle
local overlapBoxVehicleResolver = {
	result = nil,
	init = function(self)
		self.result = {};
		return self;
	end,
	callback = function(self, transformId)
		local object = transformId and g_currentMission:getNodeObject(transformId);

		if (object ~= nil and object.isa ~= nil and object:isa(Vehicle)) then
			self.result[object.rootNode] = object;
		end

		-- continue;
		return true;
	end
};

--[[
coordinate local (!) vehicle

              y+
              |   z+
              |  /
              | /
              |/
    x+ -------0------- x-
             /|
            / |
           /  |
          z-  |
              y-


     width
	 front
    0-----0
	|     |
	| #---|--- rootNode
	|  x--|--- center
	|     |
	|     |  length
	0-----0
	  back

	offsetX, offsetY and offsetZ are offsets from rootNode to center of box
]]

function vehicle_measurement.drawVehicleBox(vehicleBox, pen)
	-- diff from rotation node to vehicle node
	local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);

	local points3D = {};

	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});	
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});	
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz - vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});	
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy + vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx + vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});
	table.insert(points3D, {localToWorld(vehicleBox.rotationNode, dx - vehicleBox.width / 2 + vehicleBox.offsetX, dy - vehicleBox.height / 2 + vehicleBox.offsetY, dz + vehicleBox.length / 2 + vehicleBox.offsetZ)});

	local points2D = {};

	for _, point3D in pairs(points3D) do
		local x, y = project(unpack(point3D));
		table.insert(points2D, {x = x, y = y});
	end

	graphics.drawPoly(points2D, pen);
end

-- get vehicle width, height and length
local function mesureVehicle(vehicle, rotationNode)
	-- without position, rotation or direction data, use rotationNode and rootNode instead.
	local vehicleBox = {
		rotationNode = rotationNode or vehicle.rootNode,
		rootNode     = vehicle.rootNode,
		width        = 1,   -- vehicle.sizeWidth  or vehicle.defaultWidth  or 8,
		height       = 1,   -- 1m
		length       = 1,   -- vehicle.sizeLength or vehicle.defaultLength or 8,
		offsetX      = 0,   -- center
		offsetY      = 0.5, -- center (rootNode bottom)
		offsetZ      = 0    -- center
	};

	-- scan and grow in meter per step
	local stepSizeInMeters     = 1;
	local stepSizeInMetersHalf = stepSizeInMeters / 2;

	-- loop condition
	local recalcRequired;

	-- for debugging, draws growing steps
	local debugPen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 1, b = 0, a = 0.6 }};

	if (debugMeasurement) then
		-- draw the nativie box around the vehicle before growing
		local boxPen;

		if (vehicle.isHardAttached) then
			-- magenta
			boxPen = {thickness = 1 / g_screenHeight, color = {r = 1, g = 0, b = 1, a = 0.6 }};
		else
			-- cyan
			boxPen = {thickness = 1 / g_screenHeight, color = {r = 0, g = 1, b = 1, a = 0.6 }};
		end

		vehicle.drawVehicleBox(vehicleBox, boxPen);
	end

	repeat
		recalcRequired = false;

		------------------------------------------------------------
		-- measurement left side
		------------------------------------------------------------

		for step = 1, 20, 1 do
			-- vehicle moving, reduce flickering, take values each loop
			local rotationX, rotationY, rotationZ = getWorldRotation(vehicleBox.rotationNode);

			-- diff from rotation node to vehicle node
			local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);

			local offsetX = vehicleBox.width / 2 + stepSizeInMetersHalf;
			local x, y, z = localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + offsetX, dy + vehicleBox.offsetY, dz + vehicleBox.offsetZ);

			local centerX = x;
			local centerY = y;
			local centerZ = z;
			local extentX = stepSizeInMetersHalf;
			local extentY = vehicleBox.height / 2;
			local extentZ = vehicleBox.length / 2;

			local collisionMask   = nil;
			local includeDynamics = true;
			local includeStatics  = true;
			local exactTest       = true;

			local resolver = overlapBoxComponentsResolver:init(vehicle);

			overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

			if not resolver.result then
				break;
			end

			-- debug ----------------------------------------------------------------------------------
			if (debugMeasurement) then
				local p1 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + offsetX - extentX, dy, dz + vehicleBox.offsetZ + extentZ)));
				local p2 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + offsetX - extentX, dy, dz + vehicleBox.offsetZ - extentZ)));
				local p3 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + offsetX + extentX, dy, dz + vehicleBox.offsetZ - extentZ)));
				local p4 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + offsetX + extentX, dy, dz + vehicleBox.offsetZ + extentZ)));

				graphics.drawPoly({p1, p2, p3, p4, p1}, debugPen);
			end
			-------------------------------------------------------------------------------------------

			vehicleBox.width   = vehicleBox.width   + stepSizeInMeters;
			vehicleBox.offsetX = vehicleBox.offsetX + stepSizeInMetersHalf;
			
			recalcRequired = true;
		end

		------------------------------------------------------------
		-- measurement right side
		------------------------------------------------------------

		for step = 1, 20, 1 do
			-- vehicle moving, reduce flickering, take values each loop
			local rotationX, rotationY, rotationZ = getWorldRotation(vehicleBox.rotationNode);

			-- diff from rotation node to vehicle node
			local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);
			
			local offsetX = vehicleBox.width / 2 + stepSizeInMetersHalf;
			local x, y, z = localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - offsetX, dy + vehicleBox.offsetY, dz + vehicleBox.offsetZ);

			local centerX = x;
			local centerY = y;
			local centerZ = z;
			local extentX = stepSizeInMetersHalf;
			local extentY = vehicleBox.height / 2;
			local extentZ = vehicleBox.length / 2;

			local collisionMask   = nil;
			local includeDynamics = true;
			local includeStatics  = true;
			local exactTest       = true;

			local resolver = overlapBoxComponentsResolver:init(vehicle);

			overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

			if not resolver.result then
				break;
			end

			-- debug ----------------------------------------------------------------------------------
			if (debugMeasurement) then
				local p1 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - offsetX - extentX, dy, dz + vehicleBox.offsetZ + extentZ)));
				local p2 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - offsetX - extentX, dy, dz + vehicleBox.offsetZ - extentZ)));
				local p3 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - offsetX + extentX, dy, dz + vehicleBox.offsetZ - extentZ)));
				local p4 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - offsetX + extentX, dy, dz + vehicleBox.offsetZ + extentZ)));

				graphics.drawPoly({p1, p2, p3, p4, p1}, debugPen);
			end
			-------------------------------------------------------------------------------------------

			vehicleBox.width   = vehicleBox.width   + stepSizeInMeters;
			vehicleBox.offsetX = vehicleBox.offsetX - stepSizeInMetersHalf;
			
			recalcRequired = true;
		end

		------------------------------------------------------------
		-- measurement front
		------------------------------------------------------------

		for step = 1, 20, 1 do
			-- vehicle moving, reduce flickering, take values each loop
			local rotationX, rotationY, rotationZ = getWorldRotation(vehicleBox.rotationNode);

			-- diff from rotation node to vehicle node
			local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);
			
			local offsetZ = vehicleBox.length / 2 + stepSizeInMetersHalf;
			local x, y, z = localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX, dy + vehicleBox.offsetY, dz + vehicleBox.offsetZ + offsetZ);

			local centerX = x;
			local centerY = y;
			local centerZ = z;
			local extentX = vehicleBox.width  / 2;
			local extentY = vehicleBox.height / 2;
			local extentZ = stepSizeInMetersHalf;

			local collisionMask   = nil;
			local includeDynamics = true;
			local includeStatics  = true;
			local exactTest       = true;

			local resolver = overlapBoxComponentsResolver:init(vehicle);

			overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

			if not resolver.result then
				break;
			end

			-- debug ----------------------------------------------------------------------------------
			if (debugMeasurement) then
				local p1 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - extentX, dy, dz + vehicleBox.offsetZ + offsetZ + extentZ)));
				local p2 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - extentX, dy, dz + vehicleBox.offsetZ + offsetZ - extentZ)));
				local p3 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + extentX, dy, dz + vehicleBox.offsetZ + offsetZ - extentZ)));
				local p4 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + extentX, dy, dz + vehicleBox.offsetZ + offsetZ + extentZ)));

				graphics.drawPoly({p1, p2, p3, p4, p1}, debugPen);
			end
			-------------------------------------------------------------------------------------------

			vehicleBox.length  = vehicleBox.length  + stepSizeInMeters;
			vehicleBox.offsetZ = vehicleBox.offsetZ + stepSizeInMetersHalf;
			
			recalcRequired = true;
		end
		
		------------------------------------------------------------
		-- measurement back
		------------------------------------------------------------

		for step = 1, 20, 1 do
			-- vehicle moving, reduce flickering, take values each loop
			local rotationX, rotationY, rotationZ = getWorldRotation(vehicleBox.rotationNode);

			-- diff from rotation node to vehicle node
			local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);

			local offsetZ = vehicleBox.length / 2 + stepSizeInMetersHalf;
			local x, y, z = localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX, dy + vehicleBox.offsetY, dz + vehicleBox.offsetZ - offsetZ);

			local centerX = x;
			local centerY = y;
			local centerZ = z;
			local extentX = vehicleBox.width  / 2;
			local extentY = vehicleBox.height / 2;
			local extentZ = stepSizeInMetersHalf;

			local collisionMask   = nil;
			local includeDynamics = true;
			local includeStatics  = true;
			local exactTest       = true;

			local resolver = overlapBoxComponentsResolver:init(vehicle);

			overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

			if not resolver.result then
				break;
			end

			-- debug ----------------------------------------------------------------------------------
			if (debugMeasurement) then
				local p1 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - extentX, dy, dz + vehicleBox.offsetZ - offsetZ + extentZ)));
				local p2 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - extentX, dy, dz + vehicleBox.offsetZ - offsetZ - extentZ)));
				local p3 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + extentX, dy, dz + vehicleBox.offsetZ - offsetZ - extentZ)));
				local p4 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + extentX, dy, dz + vehicleBox.offsetZ - offsetZ + extentZ)));

				graphics.drawPoly({p1, p2, p3, p4, p1}, debugPen);
			end
			-------------------------------------------------------------------------------------------

			vehicleBox.length  = vehicleBox.length  + stepSizeInMeters;
			vehicleBox.offsetZ = vehicleBox.offsetZ - stepSizeInMetersHalf;

			recalcRequired = true;
		end

		------------------------------------------------------------
		-- measurement height (up)
		------------------------------------------------------------

		for step = 1, 20, 1 do
			-- vehicle moving, reduce flickering, take values each loop
			local rotationX, rotationY, rotationZ = getWorldRotation(vehicleBox.rotationNode);

			-- diff from rotation node to vehicle node
			local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);

			local offsetY = vehicleBox.height / 2 + stepSizeInMetersHalf;
			local x, y, z = localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX, dy + vehicleBox.offsetY + offsetY, dz + vehicleBox.offsetZ);

			local centerX = x;
			local centerY = y;
			local centerZ = z;
			local extentX = vehicleBox.width  / 2;
			local extentY = stepSizeInMetersHalf;
			local extentZ = vehicleBox.length / 2;

			local collisionMask   = nil;
			local includeDynamics = true;
			local includeStatics  = true;
			local exactTest       = true;

			local resolver = overlapBoxComponentsResolver:init(vehicle);

			overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

			if not resolver.result then
				break;
			end

			-- debug ----------------------------------------------------------------------------------
			if (debugMeasurement) then
				local p1 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - extentX, dy + vehicleBox.offsetY + offsetY + extentY, dz)));
				local p2 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX - extentX, dy + vehicleBox.offsetY + offsetY - extentY, dz)));
				local p3 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + extentX, dy + vehicleBox.offsetY + offsetY - extentY, dz)));
				local p4 = graphics.toPoint(project(localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX + extentX, dy + vehicleBox.offsetY + offsetY + extentY, dz)));

				graphics.drawPoly({p1, p2, p3, p4, p1}, debugPen);
			end
			-------------------------------------------------------------------------------------------

			vehicleBox.height  = vehicleBox.height  + stepSizeInMeters;
			vehicleBox.offsetY = vehicleBox.offsetY + stepSizeInMetersHalf;

			recalcRequired = true;
		end
		
		------------------------------------------------------------
		-- measurement height (down)
		------------------------------------------------------------
		-- ommited

	until(not recalcRequired)

	return vehicleBox;
end

local vehicleBoxCache = {};

-----------------------------------------------------------------------------------------------------------------------
local function json_toString(value)
	return "\"" .. string.gsub(tostring(value), "\"", "\\\"") .. "\"";
end

local function json_encodeBoolean(value, writer, encoder, refs)
	--table.insert(output, tostring(value));
	writer(tostring(value));
end

local function json_encodeNil(value, writer, encoder, refs)
	-- should never happen
	--table.insert(output, "null");
	writer("null");
end

local function json_encodeNumber(value, writer, encoder, refs)
	--table.insert(output, tostring(value));
	writer(tostring(value));
end

local function json_encodeString(value, writer, encoder, refs)
	--table.insert(output, json_toString(value));
	writer(json_toString(value));
end

--[[
local writer = {
	written = 0,
	init = function(stream)
	["write"] = logging.trace,
	["add"] = function(self, text)
		self.write(text);
		self.written = self.written + text.length;
	end
}
]]

local function json_encodeTable(value, writer, encoder, refs)
	refs = refs or {};

	if (refs[tostring(value)]) then
		logging.trace("json_encodeTable: stack overflow");
		writer("null");
		--table.insert(output, "null");
		return;
	end

	refs[tostring(value)] = value;

	local props = {};

	local mt = getmetatable(value);

	if (mt) then
		for k, v in pairs(mt) do
			if (type(v) ~= "function") then
				props[k] = mt[k];
			end
		end
	end

	for k, v in pairs(value) do
		if (type(v) ~= "function") then
			props[k] = value[k];
		end
	end

	--table.insert(output, "{");
	writer("{");
	local count = 0;

	for k, v in pairs(props) do
		local encode = encoder[type(v)];

		if (encode) then
			if (count > 0) then
				writer(", ");
				--table.insert(output, ", ");
			end

			--table.insert(output, json_toString(k) .. ": ");
			writer(json_toString(k) .. ": ");

			encode(v, writer, encoder, refs);
			count = count + 1;
-- todo count props
			--if (#output > 5000) then
				--logging.trace("json_encodeTable: output overflow");
				--break;
			--end
		end
	end

	--table.insert(output, "}");
	writer("}");
end

local encoder = {
	["boolean"] = json_encodeBoolean,
	["nil"]     = json_encodeNil,
	["number"]  = json_encodeNumber,
	["string"]  = json_encodeString,
	["table"]   = json_encodeTable
};

-- todo: writer
local function json_serialize(value, writer)
	local refs   = {};
	local encode = encoder[type(value)];

	if (encode) then
		encode(value, writer, encoder, refs);
	end
end

-----------------------------------------------------------------------------------------------------------------------
local test = true;

local demo = {
 bla = 125,
 bol = false,
 str = "hallo welt",
 tab = {"a", "b", "c"},
 nul = nil
};

-- vehicle boxes for collistion detection
-- Note: all boxes are aligned to the vehicle direction!
function vehicle_measurement:getVehicleBox(vehicle, boxes, options, _refs)
	options = options or {};
	_refs   = _refs   or {};
	
	if test then
		test = false;
		--logging.trace("----------------------------------------");
		--json_serialize(_G, logging.trace)
		--logging.trace("----------------------------------------");
	end

	-- check recursion
	if (_refs[vehicle]) then
		-- no need
		return;
	end

	_refs[vehicle] = true;

	local vehicleBox = nil;
	local cacheEntry = vehicleBoxCache[vehicle];

	if (cacheEntry and cacheEntry.expires > g_time) then
		-- from cache
		vehicleBox = cacheEntry.box;
	else
		local rotationNode = options.alignToFirstBox and boxes and boxes[1] and boxes[1].rootNode or vehicle.rootNode;
		vehicleBox = mesureVehicle(vehicle, rotationNode);

		-- no caching while debugging so we can see the yellow measurement lines
		if (not debugMeasurement) then
			-- add to cache
			vehicleBoxCache[vehicle] = {
				box     = vehicleBox,
				expires = g_time + 500
			};
		end
	end

	if (boxes) then
		------------------------------------------------------------
		-- detect attached objects
		------------------------------------------------------------

		-- some vehicles (front loader) can be hard attached
		-- to another vehicle (any tractor).
		-- they will be a component of the tractor vehicle.
		-- we detect them as a component of the tractor vehicle (if attached)
		-- with the overlapBoxComponentsResolver.
		-- So we dont save these kind of box (they are already a component of vehicle).
		--
		-- U can see those objects with debugMeasurement and mesureVehicle.
		if (not vehicle.isHardAttached) then
			table.insert(boxes, vehicleBox);
		end	

		-- even the vehicle is hard attached, it can have a shovel or whatever
		-- that is not a component of the tractor vehicle.
		if (vehicle.getAttachedImplements) then
			for _, implement in pairs(vehicle:getAttachedImplements()) do
				local object = implement.object;

				if (object and object.isa and object:isa(Vehicle)) then
					self:getVehicleBox(object, boxes, options, _refs);
				end
			end
		end

		------------------------------------------------------------
		-- detect objects on trailer (bale, pallets, whatever)
		------------------------------------------------------------

		if (not options.ignoreObjectsOnTrailer) then
			-- Note: can produce false results, if the area to check is to large and wider than the base vehicle size
			--       but it's better then raycast some points.

			-- vehicle moving
			local rotationX, rotationY, rotationZ = getWorldRotation(vehicleBox.rotationNode);

			-- diff from rotation node to vehicle node
			local dx, dy, dz = localToLocal(vehicleBox.rootNode, vehicleBox.rotationNode, 0, 0, 0);

			-- scan and grow in meter per step
			local stepSizeInMeters     = 1;
			local stepSizeInMetersHalf = stepSizeInMeters / 2;

			local offsetY = vehicleBox.height / 2 + stepSizeInMetersHalf;
			local x, y, z = localToWorld(vehicleBox.rotationNode, dx + vehicleBox.offsetX, dy + vehicleBox.offsetY + offsetY, dz + vehicleBox.offsetZ);

			local centerX = x;
			local centerY = y;
			local centerZ = z;
			local extentX = vehicleBox.width  / 2;
			local extentY = stepSizeInMetersHalf;
			local extentZ = vehicleBox.length / 2;

			local collisionMask   = nil;
			local includeDynamics = true;
			local includeStatics  = true;
			local exactTest       = true;

			local resolver = overlapBoxVehicleResolver:init();

			overlapBox(centerX, centerY, centerZ, rotationX, rotationY, rotationZ, extentX, extentY, extentZ, "callback", resolver, collisionMask, includeDynamics, includeStatics, exactTest);

			for _, object in pairs(resolver.result) do
				self:getVehicleBox(object, boxes, options, _refs);
			end
		end
	end

	return vehicleBox;
end
