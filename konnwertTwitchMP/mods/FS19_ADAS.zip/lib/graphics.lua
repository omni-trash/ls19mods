--[[
	GRAPHICS (2D)
	Note: drawing is not accurate and not pixel perfect ... so what
]]

-- lib
local graphics = {
};

-- export
FS19_ADAS.lib.graphics = graphics;

-- import shortcuts
local logging;
local utils;

-- locals
local RES_IMAGE_BLANK = g_currentModDirectory .. "assets/blank.png";
local imageOverlay = nil;
-- for debugging only
local trackpoints = {};

-- required
function graphics:load(mod)
	-- refs
	logging   = FS19_ADAS.lib.logging;
	utils     = FS19_ADAS.lib.utils;

	-- create overlay ...
	imageOverlay = createImageOverlay(RES_IMAGE_BLANK);
	setOverlayColor(imageOverlay, 1, 0, 0, 0.8);
end

--[[
	= Screen =

       g_screenWidth  
	         |
	+--------+--------+
	|                 |

   0,1               1,1
	+-----------------+           -+
	|                 | \          |
	|                 |  \         |
	|                 |   fovY     +- g_screenHeight
	|                 |  /         |
	|                 | /          |
	+-----------------+           -+
   0,0               1,0


	= Rotation (Radian) =

                0.5 PI
                  |
                  |
                  |
    1.0 PI -------#-------- 0 (2.0 PI)
                  |
                  |
                  |
                1.5 PI


	= math.atan2(y, x) =

                 1.57
                  |
            2.35  |  0,78
                \ | /
        3.14 -----#----- 0
		        / | \
           -2.35  | -0,78
		          |
                -1.57


	= fillRect/drawRect =

		y      width
		#----------------#
		|                |
		|                | height
		|                |
		#----------------# x
	   0,0


	= drawLine =

	  x1,y1
		o
		|
		|
		|
		#----------------o
                       x2,y2					   
]]

function graphics.getRotationInRadians(dx, dy)
	-- Note: atan2(y, x)
	local radian = math.atan2(dy, dx);

	if (radian < 0) then
		radian = radian + 2 * math.pi;
	end

	return radian;
end

-- helper
function graphics.toPoint(x, y)
	return {x = x, y = y};
end

-- screen coordinates (!)
-- draws a filled rectangle
function graphics.fillRect(x, y, width, height, color)
	if color.thickness and color.color then
		-- it's a pen
		color = color.color;
	end

	setOverlayColor(imageOverlay, color.r, color.g, color.b, color.a);
	setOverlayRotation(imageOverlay, 0, 0, 0);
	renderOverlay(imageOverlay, x, y, width, height);
end

-- screen coordinates (!)
-- draws a line
function graphics.drawLine(x1, y1, x2, y2, pen)
	local dx     = (x2 - x1);
	local dy     = (y2 - y1) / g_screenAspectRatio;
	local length = math.sqrt(dx * dx + dy * dy);
	local radian = graphics.getRotationInRadians(dx, dy);

	local rotation = {
		radian = graphics.getRotationInRadians(dx, dy),
		x = 0,
		y = 0
	};

	-- TODO: alignments (pen.align?), will be tricky, so some coordniates must be updated too
	local _sin = math.sin(rotation.radian);
	x1 = x1 + _sin * pen.thickness / g_screenAspectRatio;

	setOverlayColor(imageOverlay, pen.color.r, pen.color.g, pen.color.b, pen.color.a);
	setOverlayRotation(imageOverlay, rotation.radian, rotation.x, rotation.y);
	renderOverlay(imageOverlay, x1, y1, length, pen.thickness);
end

-- screen coordinates (!)
-- draws a polygon
function graphics.drawPoly(points, pen)
	local p1 = nil;
	local p2 = points[1];

	for i = 2, #points do
		p1 = p2;
		p2 = points[i];

		graphics.drawLine(p1.x, p1.y, p2.x, p2.y, pen);
	end
end

-- screen coordinates (!)
-- draws a rectangle border
function graphics.drawRect(x, y, width, height, pen)
	local points = {
		{x = x, y = y},
		{x = x + width, y = y},
		{x = x + width, y = y + height},
		{x = x, y = y + height},
		{x = x, y = y}
	};

	graphics.drawPoly(points, pen);
end

-- for debugging only
function graphics.drawTestSceneDiagonal()
	local yPixel = 1 / g_screenHeight;

	local colors = {
		red    = {r = 1, g = 0, b = 0, a = 0.8},
		green  = {r = 0, g = 1, b = 0, a = 0.8},
		blue   = {r = 0, g = 0, b = 1, a = 0.8},
		yellow = {r = 1, g = 1, b = 0, a = 0.8}
	};

	local redPen    = { thickness = yPixel, color = colors.red };
	local greenPen  = { thickness = yPixel, color = colors.green };
	local bluePen   = { thickness = yPixel, color = colors.blue };
	local yellowPen = { thickness = yPixel, color = colors.yellow };

	graphics.drawLine(0.5, 0.5, 1, 1, redPen);
	graphics.drawLine(0.5, 0.5, 0, 1, greenPen);
	graphics.drawLine(0.5, 0.5, 1, 0, bluePen);
	graphics.drawLine(0.5, 0.5, 0, 0, yellowPen);
end

-- for debugging only
function graphics.drawTestSceneBorder()
	-- pulse
	local duration = 5000;
	-- note: t (0, 1)
	local t = math.abs(math.sin((g_time % duration) * (math.pi * 2 / duration)));
	local rgb1 = {1, 1, 0}; -- yellow
	local rgb2 = {0, 1, 0}; -- green
	local r, g, b = MathUtil.vector3ArrayLerp(rgb1, rgb2, t);

	local pen = { 
		thickness = 10 / g_screenHeight, 
		color = {r = r, g = g, b = b, a = 0.8}
	};

	graphics.drawRect(0.25, 0.25, 0.5, 0.5, pen);
end

-- for debugging only
function graphics.drawTestSceneLines()
	local thickness = 10 / g_screenHeight;

	local colors = {
		red    = {r = 1, g = 0, b = 0, a = 0.8},
		green  = {r = 0, g = 1, b = 0, a = 0.8},
		blue   = {r = 0, g = 0, b = 1, a = 0.8}
	};

	local redPen    = { thickness = thickness, color = colors.red };
	local greenPen  = { thickness = thickness, color = colors.green };
	local bluePen   = { thickness = thickness, color = colors.blue };

	graphics.drawLine(0.5, 0.5, 0.75, 0.5,  redPen);
	graphics.drawLine(0.5, 0.5, 0.5, 0.75,  bluePen);
	graphics.drawLine(0.5, 0.5, 0.75, 0.75, greenPen);
end


-- for debugging only
function graphics.drawTestSceneRadar()
	local width    = 0.1;
	local duration = 10000;
	local rotation = (g_time % duration) * (math.pi * 2 / duration);
	local pen      = { thickness = 4 / g_screenHeight, color = { r = 1, g = 0, b = 0, a = 1}};

	setOverlayColor(imageOverlay, pen.color.r, pen.color.g, pen.color.b, pen.color.a);
	setOverlayRotation(imageOverlay, rotation, 0, 0);
	renderOverlay(imageOverlay, 0.25, 0.75, width, pen.thickness);

	--[[
			  a
	    C-----B
		|    /
		|   /
       b|  /c
	    |w/
		|/
		A

	sin(w) = a / c
	cos(w) = b / c
	]]

	-- track points (circle)
	local xoff = math.cos(rotation) * width;
	local yoff = math.sin(rotation) * width * g_screenAspectRatio;
	local point = {x = 0.25 + xoff, y = 0.75 + yoff};

	table.insert(trackpoints, point);

	-- yeah, yeah not so funny
	if (#trackpoints > 100) then
		table.remove(trackpoints, 1);
	end

	pen.thickness = 1 / g_screenHeight;
	pen.color     = { r = 1, g = 0, b = 1, a = 1};
	graphics.drawPoly(trackpoints, pen);	
end

-- for debugging only
function graphics.drawTestSceneAll()
	graphics.drawTestSceneDiagonal();
	graphics.drawTestSceneBorder();
	graphics.drawTestSceneLines();
	graphics.drawTestSceneRadar();
end
