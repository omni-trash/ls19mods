--[[
	MAIN
]]

-- lib
local main = { 
};

-- internal
local scanResult = {};

-- export
FS19_ADAS.lib.main = main;

-- import shortcuts
local config;
local debugging;
local demo;
local logging;
local utils;
local vehicle_tracker;

-- required
function main:load(mod)
	-- refs
	config          = FS19_ADAS.lib.config;
	demo            = FS19_ADAS.lib.demo;
	debugging       = FS19_ADAS.lib.debugging;
	logging         = FS19_ADAS.lib.logging;
	utils           = FS19_ADAS.lib.utils;
	vehicle_tracker = FS19_ADAS.lib.vehicle_tracker;
end

function main:loaded()
	-- global action events
	FSBaseMission.registerActionEvents = utils.combineFunction(function()
		main:registerGlobalActionEvents();
	end, FSBaseMission.registerActionEvents);

	-- player action events
	Player.registerActionEvents = utils.combineFunction(function()
		main:registerPlayerActionEvents();
	end, Player.registerActionEvents);

	-- attach to the mission start event
	FSBaseMission.onStartMission = utils.combineFunction(function()
		main:onStartMission();
	end, FSBaseMission.onStartMission);

	-- savegame
	FSCareerMissionInfo.saveToXMLFile = utils.combineFunction(function()
		config.saveSettings("FS19_ADAS", FS19_ADAS);
	end, FSCareerMissionInfo.saveToXMLFile);

	config.loadSettings("FS19_ADAS", FS19_ADAS);
end

-- unused, we dont have player action events to register
function main:registerPlayerActionEvents()
end

-- unused, we dont have global action events to register
function main:registerGlobalActionEvents()
end

-- when the mission starts
function main:onStartMission()
	-- we use a timer to call the onMissionStarted
	addTimer(0, "elapsed", {
		elapsed = function()
			main:onMissionStarted();
			return false;
		end
	});
end

-- when the mission was started
function main:onMissionStarted()
end

-- draw on game loop (each frame)
function main:draw()
	vehicle_tracker:draw();
	demo:draw();
end

function main:update(dt)
	vehicle_tracker:update(dt);
	demo:update(dt);
end
