--[[
	DEMO
]]

-- lib
local demo = {
};

-- export
FS19_ADAS.lib.demo = demo;

-- import shortcuts
local detector;
local graphics;
local logging;
local utils;

-- locals
local nextTime = 0;

local NUM_COLS     = 5;
local NUM_ROWS     = 4;
local CELL_WIDTH   = 1 / NUM_COLS;
local CELL_HEIGHT  = 1 / NUM_ROWS;
local PADDING_LEFT = 100 / g_screenWidth;
local PADDING_TOP  = 100 / g_screenHeight;

-- required
function demo:load(mod)
	-- refs
	detector  = FS19_ADAS.lib.detector;
	graphics  = FS19_ADAS.lib.graphics;
	logging   = FS19_ADAS.lib.logging;
	utils     = FS19_ADAS.lib.utils;
end

-- remember objects for a short time
-- cachedObjects[<object>] = <timestamp>
-- detectObjectsInRange will not return same objects all the time
local cachedObjects = {};

-- sorted array
local objectsInRange = {};

-- informations about the objects in range
local trackedObjects = {};

-- update interval
local nextUpdate = 0;

function demo:update(dt)
	if nextUpdate > g_time then
		return;
	end

	-- every 100ms
	nextUpdate = g_time + 100;
	demo.updateObjectsInRange();
end

local test = true;

function demo:draw()
	-- for debugging only
	--graphics.drawTestSceneAll();

	-- need to update on each draw frame, so we have the correct position
	demo.updateTrackedObjects();

	--[[
	          1         2          3          4
	
		#----------#----------#----------#----------#
		|          |          |          |          |
		|     9    |    10    |   11     |   11     |    3
		#----------#----------#----------#----------#
		|          |          |          |          |
		|     5    |     6    |    7     |    8     |    2
		#----------#----------#----------#----------#
		|          |          |          |          |
		|     1    |     2    |    3     |    4     |    1
		#----------#----------#----------#----------#
	]]

	-- split objects into areas
	local areas = {};

	for _, item in pairs(trackedObjects) do
		-- brain afk, something wrong
		local row  = math.floor(item.y / CELL_HEIGHT);
		local col  = math.floor(item.x / CELL_WIDTH);
		local area = row * NUM_COLS + col;

		-- extend (note: lua index starts at 1)
		item.row  = row  + 1;
		item.col  = col  + 1;
		item.area = area + 1;

		if not areas[item.area] then
			areas[item.area] = {};
		end

		table.insert(areas[item.area], item);
	end

	for area, items in pairs(areas) do
		demo.drawItems(area, items);
	end

	if nextTime > g_time then
		return; 
	end

	nextTime = g_time + 1000;
end


function demo.drawItems(area, items)
	local positions = {};

	-- experimentell
	table.sort(items, function(a, b)
		--return a.object.id < b.object.id;
		--return a.x * a.y < b.x * b.y;
		-- wrong center, but ok
		--return graphics.getRotationInRadians(a.x - 0.5, a.y - 0.5) > graphics.getRotationInRadians(b.x - 0.5, b.y - 0.5);
		return a.x < b.x;
	end);

	for _, item in pairs(items) do
		-- for given area (render text etc.)
		local position = positions[item.area];

		if not position then
			position = {
				gridX = (item.col - 1) * CELL_WIDTH,
				gridY = (item.row - 1) * CELL_HEIGHT
			};

			-- text output
			position.x = position.gridX;
			position.y = position.gridY + CELL_HEIGHT;

			-- padding
			position.x = position.x + PADDING_LEFT;
			position.y = position.y - PADDING_TOP;

			-- remember for next loop
			positions[item.area] = position;

			-- debugging
			--graphics.drawRect(position.gridX, position.gridY, CELL_WIDTH, CELL_HEIGHT, {thickness = 2 / g_screenHeight, color = {r = 1, g = 1, b = 0, a = 1}});
		end

		local color  = {r = 1, g = 0, b = 0, a = 0.6};
		local pen    = { thickness = 2 / g_screenHeight, color = color};

		-- draw a marker on object
		--graphics.fillRect(item.x, item.y, 10 / g_screenWidth, 10 / g_screenHeight, color);
		graphics.drawRect(item.x - 15 / g_screenWidth, item.y - 15 / g_screenHeight, 30 / g_screenWidth, 30 / g_screenHeight, {thickness = 4 / g_screenHeight, color = {
		r = 1, g = 1, b = 0, a = 0.8}});

		-- render text
		local fontSize   = HUDElement.TEXT_SIZE.DEFAULT_TEXT / g_screenHeight;
		local textWidth  = getTextWidth(fontSize,  item.info);
		local textHeight, numLines = getTextHeight(fontSize, item.info);
		local adjustY    = textHeight / numLines;
		
		-- test
		position.x = item.x;
		position.y = item.y;

		-- not directly from center (0.5, 0.5), slightly shifted
		local dx = (item.x - 0.45);
		local dy = (item.y - 0.45);

		local rotation = graphics.getRotationInRadians(dx, dy / g_screenAspectRatio);

		--[[
			  a
			C-----B
			|    /
			|   /
		   b|  /c
			|w/
			|/
			A

		sin(w) = a / c
		cos(w) = b / c
		]]

		local diagonal = math.sqrt(textWidth * textWidth + textHeight * textHeight);

		position.x = position.x + math.cos(rotation) * diagonal;
		position.y = position.y + math.sin(rotation) * diagonal;

		pen.color = {r = 1, g = 1, b = 0, a = 0.2};
		graphics.drawLine(position.x, position.y, item.x, item.y, pen);

--[[
		if (item.x < 0.5) then
			position.x = item.x - 80 / g_screenWidth;
		else
			position.x = item.x + 80 / g_screenWidth;
		end
		
		if (item.y < 0.5) then
			position.y = item.y - 80 / g_screenHeight;
		else
			position.y = item.y + 80 / g_screenHeight;
		end
]]
		--graphics.fillRect(position.x, position.y - textHeight, textWidth, textHeight, {r = 0, g = 0, b = 0, a = 0.4});

		graphics.fillRect(position.x - textWidth / 2, position.y - adjustY, textWidth, textHeight, {r = 0, g = 0, b = 0, a = 0.2});

		setTextBold(false);
		setTextColor(unpack(HUDPopupMessage.COLOR.TEXT));
		setTextAlignment(RenderText.ALIGN_LEFT);
		
		renderText(position.x - textWidth / 2, position.y, fontSize, item.info);

		-- top left
		local lineX = position.x;
		local lineY = position.y;

		-- snap to one point of text bounds
		--[[

			#------#------#
			|             |
			# TEXT        #
			|             |
			#------#------#
		]]

		if (item.x > lineX + textWidth) then
			lineX = lineX + textWidth;
		elseif (item.x > lineX) then
			lineX = lineX + (textWidth / 2);
		end

		if (item.y < lineY - textHeight) then
			lineY = lineY - textHeight;
		elseif (item.y < lineY) then
			lineY = lineY - (textHeight / 2);
		end
		
		lineX = position.x;
		lineY = position.y;

		--pen.color = {r = 1, g = 1, b = 0, a = 0.4};
		--graphics.drawLine(lineX, lineY, item.x, item.y, pen);

		-- next text position
		position.x = position.x + textWidth + 20 / g_screenWidth;

		if (position.x + 200 / g_screenWidth > position.gridX + CELL_WIDTH) then
			position.x = position.gridX;
			position.x = position.x + PADDING_LEFT;

			-- next line
			position.y = position.y - textHeight - 20 / g_screenHeight;
		end
	end
end

function demo.updateObjectsInRange()
	---------------------------------------------------------------
	-- Part I
	-- Find objects in range
	---------------------------------------------------------------

	-- 3 meters
	local includeSelf = true;
	local detectedObjects = detector.detectObjectsInRange(3, includeSelf);
	local cache = {};	

	-- add previously detected not outdated objects (remember for 1s)
	for object, timestamp in pairs(cachedObjects) do
		if (timestamp + 1000 > g_time) then
			cache[object] = timestamp;
		end
	end

	-- add/set currently detected objects in range with timestamp
	for _, object in pairs(detectedObjects) do
		cache[object] = g_time;
	end

	-- swap
	cachedObjects = cache;

	-- sorted array
	objectsInRange = {};

	for object, timestamp in pairs(cachedObjects) do
		table.insert(objectsInRange, object);
	end

	-- prevent flickering, if direct used (but now we use trackedObjects, so this sort is obsolete)
	table.sort(objectsInRange, function (a, b) 
		return a.id < b.id;
	end);
end

function demo.updateTrackedObjects()
	---------------------------------------------------------------
	-- Part II
	-- Take informations about the objects in range
	---------------------------------------------------------------

	trackedObjects = {};

	for _, object in pairs(objectsInRange) do
		local idToCheck = object.rootNode or object.nodeId or object.exactFillRootNode;

		if (idToCheck) then
			-- transform vector from world space into screen space
			local x, y, z = project(getWorldTranslation(idToCheck));

			if (z == nil or z > 1) then
				-- failed or behind us, dont show
			elseif (x < 0.1 or x > 0.9) then
				-- border 10%, dont show there
			elseif (y < 0.1 or y > 0.9) then
				-- border 10%, dont show there
			else

				local params = {
					className = object.className,
					name      = "n/a"
				};

				if (object.getName) then
					params.name = object:getName();
				end

				if (object.getFullName) then
					-- Note: getFullName when helper is active -> dataS/scripts/vehicles/Vehicle.lua(2920) : attempt to call method 'getCurrentHelper' (a nil value)
					--       This is not a problem with the AI conrolled vehicle itself, it occurs with the attachments.
					--       They are active (getIsAIActive) and they are vehicles (isa), but they dont have a helper.
					if object.isa and object:isa(Vehicle) then
						-- https://gdn.giants-software.com/documentation_scripting_fs19.php?version=script&category=41&class=446
					    local name      = object:getName();
						local storeItem = g_storeManager:getItemByXMLFilename(object.configFileName);

						if storeItem ~= nil then
							local brand = g_brandManager:getBrandByIndex(storeItem.brandIndex);

							if brand ~= nil then
								name = brand.title .. " " .. name;
							end
						end

						if object:getIsAIActive() and object.getCurrentHelper then
							name = name .. " (" .. g_i18n:getText("ui_helper") .. " " .. object:getCurrentHelper().name .. ")";
						end

						params.name = name;
					else
						params.name = object:getFullName();
					end
				end

				local objectInfo = utils.formatString("{className}\r\n{name}", params);

				table.insert(trackedObjects, {
					x = x,
					y = y,
					z = z,
					object = object,
					info   = objectInfo
				});
			end
		else
			if (test == true) then
				test = false;
				logging.trace("----------------------------------------------------------------");
				logging.printTable("bla bla", object, 2);
				--logging.trace(objectInfo);
			end
			
		end
	end

	-- sort by angle (see graphics), (obsolete)
	table.sort(trackedObjects, function(a, b)
		return math.atan2(a.y + 0.5, a.x + 0.5) > math.atan2(b.y + 0.5, b.x + 0.5);
	end);
end
