--[[
	VEHICLE_TRACKER
]]

-- lib
local vehicle_tracker = {
};

-- export
FS19_ADAS.lib.vehicle_tracker = vehicle_tracker;

-- import shortcuts
local detector;
local graphics;
local logging;
local utils;

-- update interval
local nextUpdate = 0;

-- required
function vehicle_tracker:load(mod)
	-- refs
	detector = FS19_ADAS.lib.detector;
	graphics = FS19_ADAS.lib.graphics;
	logging  = FS19_ADAS.lib.logging;
	utils    = FS19_ADAS.lib.utils;
end

-- cachedObjects (caching)
--		-> objectsInRange (updateObjectsInRange)
-- 			-> trackedObjects (updateTrackedObjects)
--
-- remember objects for a short time of period
-- cachedObjects[<object>] = <timestamp>
local cachedObjects = {};
local REMEMBER_TIME = 1000;

-- the node who was used to detect the objects
local cachedObjectsNode = nil;

-- objects picked up from cachedObjects
local objectsInRange = {};

-- informations about the objects in range
local trackedObjects = {};

-- see updateObjectsInRange
local displayTime = {};
local DISPLAY_TIMEOUT = 10000;

-- see drawItems
local DISPLAY_PULSE   = 2000;

function vehicle_tracker:update(dt)
	if nextUpdate > g_time then
		return;
	end

	-- every 100ms
	nextUpdate = g_time + 100;
	vehicle_tracker.updateObjectsInRange();
end

function vehicle_tracker:draw()
	-- for debugging only
	-- graphics.drawTestSceneAll();

	-- need to update on each draw frame, so we have the correct position
	vehicle_tracker.updateTrackedObjects();
	vehicle_tracker.drawItems(trackedObjects);
end

function vehicle_tracker.drawItems(items)
	-- pulse (markerPen)
	local rgb1 = {1, 1, 0};       -- yellow
	local rgb2 = {1, 140/255, 0}; -- orange
	local t    = utils.pulse(DISPLAY_PULSE);

	-- marker
	local markerWidth      = 30 / g_screenWidth;
	local markerHeight     = 30 / g_screenHeight;
	local markerWidthHalf  = markerWidth  / 2;
	local markerHeightHalf = markerHeight / 2;
	local r, g, b          = MathUtil.vector3ArrayLerp(rgb1, rgb2, t);
	local markerPen        = {thickness = 4 / g_screenHeight, color = {r = r, g = g, b = b, a = 0.8}};

	-- line from marker to text
	local linePen = { thickness = 2 / g_screenHeight, color = {r = r, g = g, b = b, a = 0.2}};

	-- text
	local fontSize = HUDElement.TEXT_SIZE.DEFAULT_TITLE / g_screenHeight;
	local textBackgroundColor = {r = 0, g = 0, b = 0, a = 0.2};

	-- internal
	local markerPoints = {};

	for _, item in pairs(items) do
		-- draw a marker at object position
		graphics.drawRect(item.screenX - markerWidthHalf, item.screenY - markerHeightHalf, markerWidth, markerHeight, markerPen);

		-- set text attributes before measure
		setTextBold(false);
		setTextColor(unpack(HUDPopupMessage.COLOR.TEXT));
		setTextAlignment(RenderText.ALIGN_LEFT);

		-- text measurement
		local textHeight, numLines = getTextHeight(fontSize, item.info);
		local textHeightHalf = textHeight / 2;
		local lineHeight     = textHeight / numLines;
		local textWidth      = getTextWidth(fontSize, item.info);
		local textWidthHalf  = textWidth / 2;

		-- get the radian from object to the center of the viewport
		-- not directly to center (0.5, 0.5), slightly shifted will give better xperience
		-- when enter a vehicle, so we draw not an exactly vertical line.
		local dx = (item.screenX - 0.45);
		local dy = (item.screenY - 0.45);
		local rotation = graphics.getRotationInRadians(dx, dy / g_screenAspectRatio);

		--[[
			  a
			C-----B
			|    /
			|   /
		   b|  /c
			|w/
			|/
			A

		sin(w) = a / c
		cos(w) = b / c
		]]

		-- well special case when we have more than one node at the same position
		-- so we need to extend the line length to prevent text output overlap.
		-- or we use a rotation offset to prevent text output overlap, seems good.
		-- u can find those points at:
		--		SiloPlaceable (Heulager) with LoadTrigger
		--		FS19_FI_FeedMixers.FillTypeConverter (Schweinefutter) with LoadTrigger
		local key   = item.screenX .. "#" .. item.screenY;
		local count = markerPoints[key] or 0;

		-- update rotation with additional offset
		rotation = rotation + count * (math.pi * 0.25);
		rotation = rotation % (math.pi * 2);

		-- remember how often the point has a label
		markerPoints[key] = count + 1;

		-- line length (take diagonal length of text box) to the center of text box
		local length = math.sqrt(textWidth * textWidth + textHeight * textHeight);
		local lineX  = item.screenX + math.cos(rotation) * length;
		local lineY  = item.screenY + math.sin(rotation) * length;

		-- clipped position (line to label, not to center of label)
		-- Note: is not correct computed (TODO)
		local clippedX  = lineX - math.cos(rotation) * textWidthHalf;
		local clippedY  = lineY - math.sin(rotation) * textHeightHalf;

		-- draw line from marker to the point we calculated (center of text output)
		--graphics.drawLine(lineX, lineY, item.screenX, item.screenY, linePen);
		graphics.drawLine(clippedX, clippedY, item.screenX, item.screenY, linePen);

		-- text rect
		local textX = lineX - textWidthHalf;
		local textY = lineY - textHeightHalf;

		-- text background
		graphics.fillRect(textX, textY, textWidth, textHeight, textBackgroundColor);

		-- draw text finally
		textY = textY + textHeight - lineHeight;
		renderText(textX, textY, fontSize, item.info);

		--[[
			"Hello\r\nWorld"

				#-----#
				|Hello|
			+-->o-----#
			|	|World|
			|	o-----#
			|   ^
			|   |
			|   fill rect starts here
			|
			text output starts here
		]]	
	end
end

function vehicle_tracker.updateObjectsInRange()
	---------------------------------------------------------------
	-- Part I
	-- Find objects in range
	---------------------------------------------------------------

	-- TODO: check detector implementation
	-- 
	-- Note: 
	-- detector.detectObjectsInRange will not return same objects all the time.
	-- dont know why, maybe a behaviour of overlapBox.
	--
	-- Solution:
	-- Remember (cache) the objects for a short time of period.
	--
	-- 3 meters
	local nodeToCheck = detector.getPlayerPositionNode();
	local maxDistance = 3;
	local includeSelf = true;
	local detectedObjects = detector.detectObjectsInRange(nodeToCheck, maxDistance, includeSelf);
	local cache = {};

	-- apply objects from cache only, when the nodeToCheck was same
	if (cachedObjectsNode == nodeToCheck or not cachedObjectsNode) then
		-- add previously detected not outdated objects (remember for 1s)	
		for object, timestamp in pairs(cachedObjects) do
			if (timestamp + REMEMBER_TIME > g_time) then
				cache[object] = timestamp;
			end
		end
	else
		displayTime = {};
	end

	-- add/set currently detected objects with timestamp
	for _, object in pairs(detectedObjects) do
		cache[object] = g_time;
	end

	-- swap
	cachedObjects     = cache;
	cachedObjectsNode = nodeToCheck;

	-- finally
	objectsInRange = {};

	-- cleanup/sync, remove unused items from displayTime
	for object, timestamp in pairs(displayTime) do
		if not cachedObjects[object] then
			displayTime[object] = nil;
		end		
	end

	for object, timestamp in pairs(cachedObjects) do
		-- add newly detected items to displayTime
		displayTime[object] = displayTime[object] or (g_time + DISPLAY_TIMEOUT);
		local timeout = displayTime[object];

		-- show for 10s only
		if (timeout > g_time) then
			table.insert(objectsInRange, object);
		end
	end

	-- need a sort for rendering, when one point has
	-- more than one label. without sort the label text
	-- can be switched each time.
	-- see drawItems markerPoints
	table.sort(objectsInRange, function(a, b)
		return a.id < b.id;
	end);
end

function vehicle_tracker.updateTrackedObjects()
	---------------------------------------------------------------
	-- Part II
	-- Take informations about the objects in range
	---------------------------------------------------------------

	trackedObjects = {};

	for _, object in pairs(objectsInRange) do
		local idToCheck = object.rootNode or object.nodeId or object.exactFillRootNode;

		if (idToCheck) then
			-- transform vector from world space into screen space
			local x, y, z = project(getWorldTranslation(idToCheck));

			if (z == nil or z > 1) then
				-- failed or behind us, dont show
			elseif (x < 0.1 or x > 0.9) then
				-- border 10%, dont show
			elseif (y < 0.1 or y > 0.9) then
				-- border 10%, dont show
			else

				local params = {
					className = object.className,
					name      = "n/a"
				};

				if (object.getName) then
					params.name = object:getName();
				end

				if (object.getFullName) then
					-- Note:
					-- getFullName when helper is active -> dataS/scripts/vehicles/Vehicle.lua(2920) : attempt to call method 'getCurrentHelper' (a nil value)
					-- This is not a problem with the AI conrolled vehicle itself, it occurs with the attachments.
					-- They are active (getIsAIActive) and they are vehicles (isa), but they dont have a helper.
					if object.isa and object:isa(Vehicle) then
						-- https://gdn.giants-software.com/documentation_scripting_fs19.php?version=script&category=41&class=446
					    local name      = object:getName();
						local storeItem = g_storeManager:getItemByXMLFilename(object.configFileName);

						if storeItem ~= nil then
							local brand = g_brandManager:getBrandByIndex(storeItem.brandIndex);

							if brand ~= nil then
								name = brand.title .. " " .. name;
							end
						end

						if object:getIsAIActive() and object.getCurrentHelper then
							name = name .. " (" .. g_i18n:getText("ui_helper") .. " " .. object:getCurrentHelper().name .. ")";
						end

						params.name = name;
					else
						params.name = object:getFullName();
					end
				end

				local objectInfo = utils.formatString("{className}\r\n{name}", params);

				table.insert(trackedObjects, {
					screenX = x,
					screenY = y,
					screenZ = z,
					object  = object,
					info    = objectInfo
				});
			end
		end
	end
end
