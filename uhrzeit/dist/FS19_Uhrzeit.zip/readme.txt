1.20.1.19
- first release

1.20.4.19
- updateFPS with more precision
- code refactoring
