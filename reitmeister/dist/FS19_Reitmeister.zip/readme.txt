1.20.1.19
- first release

1.20.8.16
- fitness is now displayed
