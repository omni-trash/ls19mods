1.20.1.19
- first release

1.20.8.16
- fitness is now displayed

1.20.8.24
- try to ride a horse which requires fitness first
